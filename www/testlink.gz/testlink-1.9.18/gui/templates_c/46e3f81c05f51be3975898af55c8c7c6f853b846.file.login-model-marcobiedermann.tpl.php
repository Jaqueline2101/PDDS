<?php /* Smarty version Smarty-3.1.13, created on 2018-10-06 15:07:20
         compiled from "/development/release/testlink-1.9.18/gui/templates/login-model-marcobiedermann.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16299101635bb8b38806b0f8-68122474%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '46e3f81c05f51be3975898af55c8c7c6f853b846' => 
    array (
      0 => '/development/release/testlink-1.9.18/gui/templates/login-model-marcobiedermann.tpl',
      1 => 1538830399,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16299101635bb8b38806b0f8-68122474',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'labels' => 0,
    'tlCfg' => 0,
    'tlVersion' => 0,
    'gui' => 0,
    'oauth_item' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5bb8b388205e06_25075880',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bb8b388205e06_25075880')) {function content_5bb8b388205e06_25075880($_smarty_tpl) {?><!DOCTYPE html>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("login", 'local'); ?>
<?php echo lang_get_smarty(array('var'=>'labels','s'=>'login_name,password,btn_login,new_user_q,login,demo_usage,lost_password_q,oauth_login'),$_smarty_tpl);?>

<html >
  <head>
    <meta charset="UTF-8">
    <title><?php echo $_smarty_tpl->tpl_vars['labels']->value['login'];?>
</title>
    <link rel="stylesheet" href="gui/icons/font-awesome-4.5.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="gui/themes/default/login/codepen.io/marcobiedermann/css/style.css">
  </head>
  <body class="align">
    <div class="site__container">
      <div class="grid__container">
      <img src="<?php echo $_smarty_tpl->tpl_vars['tlCfg']->value->theme_dir;?>
images/<?php echo $_smarty_tpl->tpl_vars['tlCfg']->value->logo_login;?>
"><br>
      <span><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['tlVersion']->value, ENT_QUOTES, 'UTF-8', true);?>
 </span>
      </div>
      
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->note!=''){?>
      <br>
      <div class="grid__container">
      <div class="user__feedback">
      <?php echo $_smarty_tpl->tpl_vars['gui']->value->note;?>

      </div>
      </div>
      <?php }?>

      <?php if ($_smarty_tpl->tpl_vars['tlCfg']->value->demoMode){?>
      <br>
      <div class="grid__container">
      <?php echo $_smarty_tpl->tpl_vars['labels']->value['demo_usage'];?>

      </div>
      <?php }?>

      <?php if ($_smarty_tpl->tpl_vars['tlCfg']->value->login_info!=''){?>
      <div class="text--center">
      <?php echo $_smarty_tpl->tpl_vars['tlCfg']->value->login_info;?>

      </div>
      <?php }?>
      
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->draw){?>  
        <div class="grid__container">
          <form name="login" id="login" action="login.php?viewer=<?php echo $_smarty_tpl->tpl_vars['gui']->value->viewer;?>
" method="post" class="form form--login">
            <input type="hidden" name="reqURI" value="<?php echo rawurlencode($_smarty_tpl->tpl_vars['gui']->value->reqURI);?>
"/>
            <input type="hidden" name="destination" value="<?php echo rawurlencode($_smarty_tpl->tpl_vars['gui']->value->destination);?>
"/>

            <?php if ($_smarty_tpl->tpl_vars['gui']->value->ssodisable){?>
            <input type="hidden" name="ssodisable" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->ssodisable;?>
"/>
            <?php }?>

            <div class="form__field">
              <label for="tl_login"><i class="fa fa-user"></i></label>
              <input maxlength="<?php echo $_smarty_tpl->getConfigVariable('LOGIN_MAXLEN');?>
" name="tl_login" id="tl_login" type="text" class="form__input" placeholder="<?php echo $_smarty_tpl->tpl_vars['labels']->value['login_name'];?>
" required>
            </div>

            <div class="form__field">
              <label for="tl_password"><i class="fa fa-lock"></i></label>
              <input name="tl_password" id="tl_password" type="password" class="form__input" placeholder="<?php echo $_smarty_tpl->tpl_vars['labels']->value['password'];?>
" required>
            </div>

            <div class="form__field">
              <input type="submit" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_login'];?>
">
            </div>

            <?php  $_smarty_tpl->tpl_vars['oauth_item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['oauth_item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->oauth; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['oauth_item']->key => $_smarty_tpl->tpl_vars['oauth_item']->value){
$_smarty_tpl->tpl_vars['oauth_item']->_loop = true;
?>
                <div class="button">
                <a style="text-decoration: none; color:#ffffff;" href="<?php echo $_smarty_tpl->tpl_vars['oauth_item']->value->link;?>
">
                <img src="<?php echo $_smarty_tpl->tpl_vars['tlCfg']->value->theme_dir;?>
images/<?php echo $_smarty_tpl->tpl_vars['oauth_item']->value->icon;?>
" style="height: 42px; vertical-align:middle;">
                <span style="padding: 10px;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['oauth_login'];?>
<?php echo $_smarty_tpl->tpl_vars['oauth_item']->value->name;?>
</span></a>
                </div>
            <?php } ?>
          </form>

          <p class="text--center">
          <?php if ($_smarty_tpl->tpl_vars['gui']->value->user_self_signup){?>
            <a href="firstLogin.php?viewer=new"><?php echo $_smarty_tpl->tpl_vars['labels']->value['new_user_q'];?>
</a> &nbsp; &nbsp;
          <?php }?>

              
          <?php if ($_smarty_tpl->tpl_vars['gui']->value->external_password_mgmt==0&&$_smarty_tpl->tpl_vars['tlCfg']->value->demoMode==0){?>
            <a href="lostPassword.php?viewer=new"><?php echo $_smarty_tpl->tpl_vars['labels']->value['lost_password_q'];?>
</a>
          <?php }?>
          </p> 
        </div>
      <?php }?>
  </div>
</body>
</html>
<?php }} ?>